gcloud dataproc jobs submit pyspark spark-etl/hive-scripts/hivesql-etl.py \
--cluster=hive-sql --region=us-central1 