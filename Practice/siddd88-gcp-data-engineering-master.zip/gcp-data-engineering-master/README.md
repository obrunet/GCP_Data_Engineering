# gcp-data-engineering
Batch Processing , orchestration, spark structured Streaming and a lot more
